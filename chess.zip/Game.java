import java.awt.Color;

/**
 * Represents a game
 * of chess with all the
 * pieces working functionally
 * and two players (
 * can be human, smart, or random).
 * 
 * @author Linda Zeng
 * @version 4.9.23
 */
public class Game
{
    /**
     * Runs the chess game.
     * Puts all the pieces on board,
     * displays board, creates two
     * players.
     * 
     * @param args String array from java for main method
     */
    public static void main(String[] args)
    {
        Board board = new Board();
        Piece blackKing = new King(Color.BLACK, "black_king.gif");
        blackKing.putSelfInGrid(board, new Location(0, 4));
        Piece whiteKing = new King(Color.WHITE, "white_king.gif");
        whiteKing.putSelfInGrid(board, new Location(7,4));
        Piece blackRook1 = new Rook(Color.BLACK, "black_rook.gif");
        blackRook1.putSelfInGrid(board, new Location(0,0));
        Piece blackRook2 = new Rook(Color.BLACK, "black_rook.gif");
        blackRook2.putSelfInGrid(board, new Location(0,7));
        Piece whiteRook1 = new Rook(Color.WHITE, "white_rook.gif");
        whiteRook1.putSelfInGrid(board, new Location(7, 0));
        Piece whiteRook2 = new Rook(Color.WHITE, "white_rook.gif");
        //whiteRook2.putSelfInGrid(board, new Location(7,7));
        for (int i = 0; i < 8; i++)
        {
            Piece whitePawn = new Pawn(Color.WHITE, "white_pawn.gif");
            //whitePawn.putSelfInGrid(board, new Location(6, i));
            Piece blackPawn = new Pawn(Color.BLACK, "black_pawn.gif");
            blackPawn.putSelfInGrid(board, new Location(1, i));
        }
        Piece blackBishop1 = new Bishop(Color.BLACK, "black_bishop.gif");
        blackBishop1.putSelfInGrid(board, new Location(0,2));
        Piece blackBishop2 = new Bishop(Color.BLACK, "black_bishop.gif");
        blackBishop2.putSelfInGrid(board, new Location(0,5));
        Piece whiteBishop1 = new Bishop(Color.WHITE, "white_bishop.gif");
        whiteBishop1.putSelfInGrid(board, new Location(7, 2));
        Piece whiteBishop2 = new Bishop(Color.WHITE, "white_bishop.gif");
        whiteBishop2.putSelfInGrid(board, new Location(7,5));
        Piece blackKnight1 = new Knight(Color.BLACK, "black_knight.gif");
        blackKnight1.putSelfInGrid(board, new Location(0,1));
        Piece blackKnight2 = new Knight(Color.BLACK, "black_knight.gif");
        blackKnight2.putSelfInGrid(board, new Location(0,6));
        Piece whiteKnight1 = new Knight(Color.WHITE, "white_knight.gif");
        whiteKnight1.putSelfInGrid(board, new Location(7, 1));
        Piece whiteKnight2 = new Knight(Color.WHITE, "white_knight.gif");
        whiteKnight2.putSelfInGrid(board, new Location(7,6));
        Piece blackQueen = new Queen(Color.BLACK, "black_queen.gif");
        blackQueen.putSelfInGrid(board, new Location(0, 3));
        Piece whiteQueen = new Queen(Color.WHITE, "white_queen.gif");
        whiteQueen.putSelfInGrid(board, new Location(7,3));
        BoardDisplay display = new BoardDisplay(board);
        /*for (Move m: board.allMoves(Color.WHITE))
        {
            display.setColor(m.getDestination(), Color.YELLOW);
        }*/
        Player player = new SmartPlayer(board, "Smart Opponent", Color.WHITE);
        Player player2 = new HumanPlayer(board, "You", Color.BLACK, display);
        play(board, display, player, player2);
    }

    /**
     * Gets and
     * executes the next
     * turn for a given player,
     * lighitng up the board.
     * 
     * @param board the board the turn is executed on
     * @param display the display that shows the turn lit up
     * @param player the player whose turn is being executed
     */
    private static void nextTurn(Board board, BoardDisplay display, Player player)
    {
        try
        {
            Thread.sleep(500);
            display.setTitle(player.getName());
            Move move = player.nextMove();
            board.executeMove(move);
            display.clearColors();
            display.setColor(move.getSource(), Color.YELLOW);
            display.setColor(move.getDestination(), Color.YELLOW);
        }
        catch (InterruptedException e)
        {
        }
    }

    /*private static boolean hasLost(Board board, Color color)
    {
        return (board.allMoves(color).size() == 0);
    }*/

    /**
     * Plays chess by
     * repeatedly calling
     * each player for a turn.
     * 
     * @param board the board to be played on
     * @param display the display to show the game
     * @param white the player with white pieces
     * @param black the player with black pieces
     */
    public static void play(Board board, BoardDisplay display, Player white, Player black)
    {
        while (true)
        {
            nextTurn(board, display, white);
            nextTurn(board, display, black);
        }
        /*while (!(hasLost(board, Color.WHITE) || hasLost(board, Color.BLACK)))
        {
            nextTurn(board, display, white);
            if (hasLost(board, Color.BLACK))
            {
                System.out.println("checkmate!");
            }
            else if (board.inCheck(Color.BLACK))
            {  
                System.out.println("check!");
            }
            nextTurn(board, display, black);
            if (hasLost(board, Color.WHITE))
            {
                System.out.println("checkmate!");
            }
            else if (board.inCheck(Color.WHITE))
            {
                System.out.println("check!");
            }
        }*/
    }
}